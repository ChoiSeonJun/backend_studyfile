import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.dto.Student;
import com.service.StudentService;

public class StudentTest {

	public static void main(String[] args) {

		while (true) {
			System.out.println("******************************");
			System.out.println("    [학생 정보 관리 메뉴]      ");
			System.out.println("******************************");
			System.out.println("1. 전체 학생 목록");
			System.out.println("2. 학생 이름 검색");
			System.out.println("3. 학생 입학년도 범위 검색 (예> 2000부터 2003년까지)");
			System.out.println("4. 학생 학번으로 다중 검색 (쉼표 구분자)");
			System.out.println("5. 학생 휴학 일괄 수정");
			System.out.println("6. 학과 정원 일괄 수정");
			System.out.println("7. 학생 학점 검색");
			System.out.println("0. 종료");
			System.out.println("******************************");
			Scanner scanner = new Scanner(System.in);
			System.out.print("메뉴 입력 => ");
			int n = scanner.nextInt();

			if (n == 1) {
				StudentService service = new StudentService();
				ArrayList<Student> list = service.selectAllStudent();
				System.out.println("==========================================================");
				System.out.println("학번\t이름\t주민번호\t주소\t입학년도\t휴학여부");
				System.out.println("----------------------------------------------------------");
				for (Student s : list) {
					System.out.println(s.getStuNo() + "\t" + s.getStuName() + "\t" + s.getStuSsn() + "\t"
							+ s.getStuAdress() + "\t" + s.getEntDate() + "\t" + s.getAbsYn());
				}
				System.out.println("총 학생 수 : " + list.size() + "명");
			} else if (n == 2) {
				System.out.print("검색할 학생명을 입력하시오 => ");
				String str = scanner.next();
				StudentService service = new StudentService();
				ArrayList<Student> list = service.selectByName(str);
				System.out.println("==========================================================");
				System.out.println("학번\t이름\t주민번호\t주소\t입학년도\t휴학여부");
				System.out.println("----------------------------------------------------------");
				for (Student s : list) {
					System.out.println(s.getStuNo() + "\t" + s.getStuName() + "\t" + s.getStuSsn() + "\t"
							+ s.getStuAdress() + "\t" + s.getEntDate() + "\t" + s.getAbsYn());
				}
				System.out.println("총 학생 수 : " + list.size() + "명");

			} else if (n == 3) {
				System.out.print("시작 입학년도를 입력하시오 => ");
				String startYear = scanner.next();
				System.out.print("끝 입학년도를 입력하시오 = > ");
				String endYear = scanner.next();

				StudentService service = new StudentService();
				HashMap<Integer, String> map = new HashMap<>();
				map.put(0, startYear);
				map.put(1, endYear);
				ArrayList<Student> list = service.selectByEntranceDate(map);
				System.out.println("==========================================================");
				System.out.println("학번\t이름\t주민번호\t주소\t입학년도\t휴학여부");
				System.out.println("----------------------------------------------------------");
				for (Student s : list) {
					System.out.println(s.getStuNo() + "\t" + s.getStuName() + "\t" + s.getStuSsn() + "\t"
							+ s.getStuAdress() + "\t" + s.getEntDate() + "\t" + s.getAbsYn());
				}
				System.out.println("총 학생 수 : " + list.size() + "명");
			} else if (n == 4) {
				System.out.print("검색할 학생의 학번을 입력하시오 => ");
				String searchNo = scanner.next(); //A674033,A656014,A612025
				
				StudentService service = new StudentService();
				ArrayList<Student> list = service.selectBySearchNo(searchNo);
				System.out.println("==========================================================");
				System.out.println("학번\t이름\t주민번호\t주소\t입학년도\t휴학여부");
				System.out.println("----------------------------------------------------------");
				for (Student s : list) {
					System.out.println(s.getStuNo() + "\t" + s.getStuName() + "\t" + s.getStuSsn() + "\t"
							+ s.getStuAdress() + "\t" + s.getEntDate() + "\t" + s.getAbsYn());
				}
				System.out.println("총 학생 수 : " + list.size() + "명");

			} else if(n == 5) {
				System.out.print("수정할 학생의 학번을 입력하시오 => ");
				String searchNo = scanner.next(); //9556017,9732111,9747034
				
				StudentService service = new StudentService();
				int num = service.absenceChange(searchNo);
				System.out.println("총 변경된 학생 수 : " + num + "명");
				
			} else if (n == 6) {
				StudentService service = new StudentService();
				int num = service.capacityChange();
				System.out.println("총 변경된 학과 수 : " + num + "개");
			} else if (n ==7 ) {
				StudentService service = new StudentService();
				System.out.print("학생의 학번을 입력하시오 =>");
				String stuNo = scanner.next(); //9556017
				
				List<HashMap<String, String>> list = service.gradeSearch(stuNo);
				System.out.println("==========================================================");
				System.out.println("학기\t학번\t이름\t과목명\t\t점수\t학점");
				System.out.println("----------------------------------------------------------");
			
				for (HashMap<String, String> s : list) {
						System.out.println(s.get("term_no")+"\t"+s.get("student_no")+"\t"+s.get("student_name")+"\t"+s.get("class_name")+"\t"+s.get("point")+"\t"+s.get("grade"));
			
				}
			} else if (n == 0) {
				System.out.println("프로그램이 종료 되었습니다.");
				System.exit(0);
			}
		} // end while
	}// end main
}
