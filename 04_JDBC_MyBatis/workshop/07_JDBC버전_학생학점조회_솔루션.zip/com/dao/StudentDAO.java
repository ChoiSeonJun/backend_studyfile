package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.dto.Student;

public class StudentDAO {
	
	public List<HashMap<String, String>> gradeSearch(Connection con, String stuNo){
		List<HashMap<String, String>> list = new ArrayList<>();
	
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "select term_no, s.student_no, student_name, class_name, to_char(point, '0.00') point,";
			   sql += " case when point >= 4.0 then 'A학점' when point >= 3.5 then 'B학점' when point >= 3.0 then 'C학점' when point >= 2.0 then 'D학점' ELSE 'F학점' end grade";
			   sql += " from TB_STUDENT s join TB_GRADE g on s.student_no = g.student_no join tb_class c on g.class_no = c.class_no";
			   sql += " where s.student_no = ?";
	
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, stuNo);
			rs = pstmt.executeQuery(); 
			int i = 0;
			while(rs.next()) { 
				HashMap<String, String> map = new HashMap<>();
				map.put("term_no", rs.getString("term_no"));
				map.put("student_no", rs.getString("student_no"));
				map.put("student_name", rs.getString("student_name"));
				map.put("class_name", rs.getString("class_name"));
				map.put("point", rs.getString("point"));
				map.put("grade", rs.getString("grade"));
				i++;
				list.add(map);
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public int capacityChange(Connection con) {
		int n = 0 ;
		PreparedStatement pstmt = null;
		
		String sql = "update tb_department set capacity = case when capacity between 0 and 20 then capacity+5";
			   sql += " when capacity between 21 and 25 then capacity+4 when capacity between 26 and 30 then capacity+3 else capacity end";
		
		try {
			pstmt = con.prepareStatement(sql);
			n = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt!=null)pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return n;
	}
	
	public int absenceChange(Connection con, String searchNo) {
		int n = 0;
		PreparedStatement pstmt = null;
		
		String[] search = searchNo.split(",");
		String binaryVariable = null;
		for (int i=0; i<search.length; i++) {
			if(i==0) {
				binaryVariable = "?";
				continue;
			}
			binaryVariable +=",?";
		}
		
		String sql = "update tb_student set absence_yn = 'Y' where student_no in (" + binaryVariable +")";
		try {
			pstmt = con.prepareStatement(sql);
			for (int i = 0; i<search.length; i++) {
				pstmt.setString(i+1, search[i]);
			}
			n = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if( pstmt != null) pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return n;
	}

	public ArrayList<Student> selectBySearchNo(Connection con, String searchNo) {
		ArrayList<Student> list = new ArrayList<Student>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select student_no 학번, student_name 이름, rpad(substr(student_ssn, 0, 8), 14, '*') 주민번호,";
		sql += " case when student_address is null then '**주소미상**' else substr(student_address, 0, 10)||'...' end 주소,";
		sql += " to_char(entrance_date, 'yyyy/mm/dd') 입학년도, absence_yn 휴학여부";
		//sql += " from tb_student where student_no in (?, ?) order by 1";
		sql += " from tb_student where student_no in ( ";

		try {
	
			String [] xxx = searchNo.split(",");
			for(int i=0;i<xxx.length;i++) {
				sql +="?";
				if(i!=(xxx.length-1)) sql+=",";
			}
			sql+=") order by 1";
System.out.println("sql>" + sql);			

            pstmt = con.prepareStatement(sql);
            for(int i=0;i<xxx.length;i++) {
				pstmt.setString(i+1, xxx[i]);
			}

			rs = pstmt.executeQuery();
			while (rs.next()) {
				String stuNo = rs.getString("학번");
				String stuName = rs.getString("이름");
				String stuSsn = rs.getString("주민번호");
				String stuAdress = rs.getString("주소");
				String entDate = rs.getString("입학년도");
				String absYn = rs.getString("휴학여부");

				Student s = new Student(stuNo, stuName, stuSsn, stuAdress, entDate, absYn);
				list.add(s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public ArrayList<Student> selectByEntranceDate(Connection con, HashMap<Integer, String> map){
		ArrayList<Student> list = new ArrayList<Student>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "select student_no 학번, student_name 이름, rpad(substr(student_ssn, 0, 8), 14, '*') 주민번호,";
		   	   sql += " case when student_address is null then '**주소미상**' else substr(student_address, 0, 10)||'...' end 주소,";
		   	   sql += " to_char(entrance_date, 'yyyy/mm/dd') 입학년도, absence_yn 휴학여부";
		   	   sql += " from tb_student where to_char(entrance_date, 'YYYY') between ? and ? order by 1";
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, map.get(0)); //startYear
			pstmt.setString(2, map.get(1)); //endYear
			rs = pstmt.executeQuery();
			while(rs.next()) {
				String stuNo = rs.getString("학번");
				String stuName = rs.getString("이름");
				String stuSsn = rs.getString("주민번호");
				String stuAdress = rs.getString("주소");
				String entDate = rs.getString("입학년도");
				String absYn = rs.getString("휴학여부");
				
				Student s = new Student(stuNo, stuName, stuSsn, stuAdress, entDate,	absYn);
				list.add(s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		   	   
		return list; 
	
	}
	public ArrayList<Student> selectByName(Connection con, String str) {
		ArrayList<Student> list = new ArrayList<Student>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select student_no 학번, student_name 이름, rpad(substr(student_ssn, 0, 8), 14, '*') 주민번호,";
		sql += " case when student_address is null then '**주소미상**' else substr(student_address, 0, 10)||'...' end 주소,";
		sql += " to_char(entrance_date, 'yyyy/mm/dd') 입학년도, absence_yn 휴학여부";
		sql += " from tb_student where student_name like ? order by 1";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%" + str + "%");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String stuNo = rs.getString("학번");
				String stuName = rs.getString("이름");
				String stuSsn = rs.getString("주민번호");
				String stuAdress = rs.getString("주소");
				String entDate = rs.getString("입학년도");
				String absYn = rs.getString("휴학여부");

				Student s = new Student(stuNo, stuName, stuSsn, stuAdress, entDate, absYn);
				list.add(s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public ArrayList<Student> selectAllStudent(Connection con) {
		ArrayList<Student> list = new ArrayList<Student>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select student_no 학번, student_name 이름, rpad(substr(student_ssn, 0, 8), 14, '*') 주민번호, substr(student_address, 0, 10)||'...' 주소, to_char(entrance_date, 'yyyy/mm/dd') 입학년도, absence_yn 휴학여부";
		sql += " from tb_student order by 1";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String stuNo = rs.getString("학번");
				String stuName = rs.getString("이름");
				String stuSsn = rs.getString("주민번호");
				String stuAdress = rs.getString("주소");
				String entDate = rs.getString("입학년도");
				String absYn = rs.getString("휴학여부");

				Student s = new Student(stuNo, stuName, stuSsn, stuAdress, entDate, absYn);
				list.add(s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
}
