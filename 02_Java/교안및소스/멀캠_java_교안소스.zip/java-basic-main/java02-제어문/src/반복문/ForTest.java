package 반복문;

public class ForTest {

	public static void main(String[] args) {
		//시작값, 조건식, 증감값
		for (int i = 0; i < 10; i++) {
			//조건이 만족했을 때, 비교연산자의 결과가 true!일때
			//실행내용
			System.out.println("내가 반복");
		}
	}

}
