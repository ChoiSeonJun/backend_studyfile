package 변수;

public class 기본데이터2 {

	public static void main(String[] args) {

		byte age = 100;
		short wallet = 20000;
		int money = 5000000;
		long space = 1000000000L;
		System.out.println("내 은행에 든 돈 : " + money + "원");
		
		double height = 185.5;
		float weight = 88.8f;
		System.out.println("내 키는 " + height);
		
		
		char gender = '남';
		System.out.println("내 성별은 " + gender);
		
		String name = "홍길동";
		System.out.println("내 이름은  " + name);
				
	}

}
