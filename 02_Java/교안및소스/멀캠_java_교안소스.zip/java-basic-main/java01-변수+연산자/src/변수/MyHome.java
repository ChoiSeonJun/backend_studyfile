package 변수;

public class MyHome {
//파일이름은 대문자로 시작해서, 낙타표기법을 지켜주세요.
//MyHome:연결되는 단어의 첫글자는 대문자!!
	public static void main(String[] args) {
		//변수명은 무조건 소문자로 시작!!
		//연결되는 단어가 있으면 낙타표기법
		int myAge = 100;
		String myTel = "011";
		String ssn = "880101";
		final String COMPANY = "메가더조은";//상수
//		COMPANY = "mega";
		//final => 수정불가
	}
}

