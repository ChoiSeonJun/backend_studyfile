package 제어문;

public class 조건문 {

	public static void main(String[] args) {
		int x = 100;
		if (x >= 200) {//비교연산자가 반드시 들어가야함.
			System.out.println("200보다 크군요!");
		} else {
			System.out.println("200보다 작군요!");

		}
	}

}
