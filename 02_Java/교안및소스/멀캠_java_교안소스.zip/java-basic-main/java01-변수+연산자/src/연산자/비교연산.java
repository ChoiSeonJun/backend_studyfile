package 연산자;

public class 비교연산 {

	public static void main(String[] args) {
		//비교연산자의 결과가 boolean(논리형!)
		int x = 200;
		int y = 100;
		System.out.println("일치? " + (x == y));
		System.out.println("불일치? " + (x != y));
		System.out.println("이상? " + (x >= y));
		System.out.println("초과? " + (x > y));
	}
}
