package 연산자;

public class 삼항연산자 {

	public static void main(String[] args) {
		int hot = 25;
		String food = (hot > 30)? "아이스크림" : "아이스 아메리카노";
		System.out.println(food);
	}

}
