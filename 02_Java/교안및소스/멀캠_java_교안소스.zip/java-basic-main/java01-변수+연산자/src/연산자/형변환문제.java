package 연산자;

public class 형변환문제 {

	public static void main(String[] args) {
//		byte x = 100;
//		int y = x; // 자동형변환

//		int x = 300;
//		byte y = x; //형변환불가
//
//		double x = 400; //8바이트
//		int y = (int)x; //강제형변환
//
//		int x = 400;
//		double y = x; //자동형변환

	}

}
