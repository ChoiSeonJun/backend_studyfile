package 클래스만들기;

public class 계산기 {
	// 기능정의
	// 더하기
	public void call() {
		
	}
	public void add() {
		System.out.println("더하기 기능 처리 내용");
	}

	// 빼기
	public void minus() {
		System.out.println("빼기 기능 처리 내용");
	}

	// 곱하기
	public void mul() {
		System.out.println("곱하기 기능 처리 내용");
	}

	// 나누기
	public void div() {
		System.out.println("나누기 기능 처리 내용");
	}
}
