package 클래스만들기;

public class 학생 {
	//2개 기능(처리) 정의
	public void school() {
		System.out.println("학교가다.");
	}
	public void study() {
		System.out.println("공부하다.");
	}
	
}
