package 상속;

public class 원더우먼사용 {

	public static void main(String[] args) {
		원더우먼 wonder = new 원더우먼("다이애나", 100, "밥", true);
		System.out.println(wonder);
	}

}
