package workshop08.shape;

public interface Movable{
    public abstract void move(int x, int y);
}

