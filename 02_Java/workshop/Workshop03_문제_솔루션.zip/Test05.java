
public class Test05 {
	public static void main(String[] args) {
		int value = (int)(Math.random()*6)+1;
		System.out.println(value);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
